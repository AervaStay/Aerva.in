-- migration_confirmation_code.sql
-- A confirmation code for every booking, shown to the guest and the host
-- and quoted in emails. The code is eight RANDOM digits (e.g. 48291374): it
-- says nothing about the booking, the guest or anything else.
--
-- confirmation_codes is the register of every code ever issued. A code is
-- claimed there before it is put on a booking, so a code can never be
-- issued twice — not even after a booking is cancelled or removed.
-- Safe to run more than once.

ALTER TABLE orders ADD COLUMN IF NOT EXISTS confirmation_code text;
CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_confirmation_code ON orders (confirmation_code) WHERE confirmation_code IS NOT NULL;

CREATE TABLE IF NOT EXISTS confirmation_codes (
  code text PRIMARY KEY,
  order_id integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Any code already on a booking is registered too, so it is never reused.
INSERT INTO confirmation_codes (code, order_id)
SELECT confirmation_code, id FROM orders WHERE confirmation_code IS NOT NULL
ON CONFLICT (code) DO NOTHING;

-- Check (should return: confirmation_code, confirmation_codes)
SELECT 'confirmation_code' AS added WHERE EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'orders' AND column_name = 'confirmation_code')
UNION ALL SELECT 'confirmation_codes' WHERE to_regclass('confirmation_codes') IS NOT NULL;
